<footer class="footer text-center text-sm-left"> &copy;<a href="https://hyzventures.com/" target="_blank"> Hyz Ventures Intl Pvt Ltd</a></footer><!--end footer-->
            </div>
            <!-- end page content -->
        </div>
        <!-- end page-wrapper -->




        <!-- jQuery  -->
        <script src="{{ asset('backend/assets/js/jquery.min.js') }}"></script>
        <script src="{{ asset('backend/assets/js/bootstrap.bundle.min.js') }}"></script>
        <script src="{{ asset('backend/assets/js/metismenu.min.js') }}"></script>
        <script src="{{ asset('backend/assets/js/waves.js') }}"></script>
        <script src="{{ asset('backend/assets/js/feather.min.js') }}"></script>
        <script src="{{ asset('backend/assets/js/simplebar.min.js') }}"></script>
        <script src="{{ asset('backend/assets/js/jquery-ui.min.js') }}"></script>
        <script src="{{ asset('backend/assets/js/moment.js') }}"></script>
        <script src="{{ asset('backend/plugins/daterangepicker/daterangepicker.js') }}"></script>

        <!-- Required datatable js -->
        <script src="{{ asset('backend/plugins/datatables/jquery.dataTables.min.js') }}"></script>
        <script src="{{ asset('backend/plugins/datatables/dataTables.bootstrap4.min.js') }}"></script>
        <!-- Buttons examples -->
        <script src="{{ asset('backend/plugins/datatables/dataTables.buttons.min.js') }}"></script>
        <script src="{{ asset('backend/plugins/datatables/buttons.bootstrap4.min.js') }}"></script>
        <script src="{{ asset('backend/plugins/datatables/jszip.min.js') }}"></script>
        <script src="{{ asset('backend/plugins/datatables/pdfmake.min.js') }}"></script>
        <script src="{{ asset('backend/plugins/datatables/vfs_fonts.js') }}"></script>
        <script src="{{ asset('backend/plugins/datatables/buttons.html5.min.js') }}"></script>
        <script src="{{ asset('backend/plugins/datatables/buttons.print.min.js') }}"></script>
        <script src="{{ asset('backend/plugins/datatables/buttons.colVis.min.js') }}"></script>
        <!-- Responsive examples -->
        <script src="{{ asset('backend/plugins/datatables/dataTables.responsive.min.js') }}"></script>
        <script src="{{ asset('backend/plugins/datatables/responsive.bootstrap4.min.js') }}"></script>
        <script src="{{ asset('backend/assets/pages/jquery.datatable.init.js') }}"></script>

        <!-- App js -->
        <script src="{{ asset('backend/assets/js/app.js') }}"></script>

    </body>

</html>
